"use strict";
var Contacts = (function () {
    function Contacts() {
    }
    return Contacts;
}());
exports.Contacts = Contacts;
var Order = (function () {
    function Order() {
        this.orderstatus = '1';
        this.ordernum = 0;
        this.mid = 0;
        this.userorder = 0;
    }
    return Order;
}());
exports.Order = Order;
var Product = (function () {
    function Product() {
    }
    return Product;
}());
exports.Product = Product;
var Hosuser = (function () {
    function Hosuser() {
    }
    return Hosuser;
}());
exports.Hosuser = Hosuser;
var Categories = (function () {
    function Categories() {
    }
    return Categories;
}());
exports.Categories = Categories;
var MainproductDt = (function () {
    function MainproductDt() {
    }
    return MainproductDt;
}());
exports.MainproductDt = MainproductDt;
var Mainstockin = (function () {
    function Mainstockin() {
    }
    return Mainstockin;
}());
exports.Mainstockin = Mainstockin;
var Mainstockout = (function () {
    function Mainstockout() {
    }
    return Mainstockout;
}());
exports.Mainstockout = Mainstockout;
var Supplier = (function () {
    function Supplier() {
    }
    return Supplier;
}());
exports.Supplier = Supplier;
//# sourceMappingURL=model.js.map