<script>
d = 1;
alert(d);
</script>
